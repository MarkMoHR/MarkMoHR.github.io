##  Requirements
  - tensorflow==1.12.0 (used for pasting)

  - numpy==1.19.2

  - pillow==6.2.0

  - opencv==3.4.2

    

## File Structure

There are four files under each image:
  - input.png: the input image

  - output_vector.npz: the output vector data stored in npz

  - output_rendered.png: rendered image of the output vector result

  - output_order.png: rendered image with drawing order

    

## Re-generate the Vector Results

Run the command like this:

```
python visualize_drawing.py --data clean --image muten
```

  - `--data` can be clean/rough/face
  - `--image` is the image name
  - A `regenerate/` folder containing the re-generated results is created under `<data>/<image>` (might need to wait for some seconds)