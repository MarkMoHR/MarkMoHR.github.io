import os
import cv2
import argparse
import numpy as np
from PIL import Image
import tensorflow as tf

os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def rgb_trans(split_num, break_values):
    slice_per_split = split_num // 8
    break_values_head, break_values_tail = break_values[:-1], break_values[1:]

    results = []

    for split_i in range(8):
        break_value_head = break_values_head[split_i]
        break_value_tail = break_values_tail[split_i]

        slice_gap = float(break_value_tail - break_value_head) / float(slice_per_split)
        for slice_i in range(slice_per_split):
            slice_val = break_value_head + slice_gap * slice_i
            slice_val = int(round(slice_val))
            results.append(slice_val)

    return results


def get_colors(color_num):
    split_num = (color_num // 8 + 1) * 8

    r_break_values = [0, 0, 0, 0, 128, 255, 255, 255, 128]
    g_break_values = [0, 0, 128, 255, 255, 255, 128, 0, 0]
    b_break_values = [128, 255, 255, 255, 128, 0, 0, 0, 0]

    r_rst_list = rgb_trans(split_num, r_break_values)
    g_rst_list = rgb_trans(split_num, g_break_values)
    b_rst_list = rgb_trans(split_num, b_break_values)

    # print('r_rst_list', len(r_rst_list))
    # print(r_rst_list)
    # print('g_rst_list', len(g_rst_list))
    # print(g_rst_list)
    # print('b_rst_list', len(b_rst_list))
    # print(b_rst_list)

    assert len(r_rst_list) == len(g_rst_list)
    assert len(b_rst_list) == len(g_rst_list)

    rgb_color_list = [(r_rst_list[i], g_rst_list[i], b_rst_list[i]) for i in range(len(r_rst_list))]
    return rgb_color_list


def normal(x, width):
    return (int)(x * (width - 1) + 0.5)


def draw(f, width=128):
    x0, y0, x1, y1, x2, y2, z0, z2, w0, w2 = f
    x1 = x0 + (x2 - x0) * x1
    y1 = y0 + (y2 - y0) * y1
    x0 = normal(x0, width * 2)
    x1 = normal(x1, width * 2)
    x2 = normal(x2, width * 2)
    y0 = normal(y0, width * 2)
    y1 = normal(y1, width * 2)
    y2 = normal(y2, width * 2)
    z0 = (int)(1 + z0 * width // 2)
    z2 = (int)(1 + z2 * width // 2)
    canvas = np.zeros([width * 2, width * 2]).astype('float32')
    tmp = 1. / 100
    for i in range(100):
        t = i * tmp
        x = (int)((1 - t) * (1 - t) * x0 + 2 * t * (1 - t) * x1 + t * t * x2)
        y = (int)((1 - t) * (1 - t) * y0 + 2 * t * (1 - t) * y1 + t * t * y2)
        z = (int)((1 - t) * z0 + t * z2)
        w = (1 - t) * w0 + t * w2
        cv2.circle(canvas, (y, x), z, w, -1)
    return 1 - cv2.resize(canvas, dsize=(width, width))


class DiffPastingV3(object):
    def __init__(self, raster_size):
        self.patch_canvas = tf.placeholder(dtype=tf.float32,
                                           shape=(None, None, 1))  # (raster_size, raster_size, 1), [0.0-BG, 1.0-stroke]
        self.cursor_pos_a = tf.placeholder(dtype=tf.float32, shape=(2))  # (2), float32, in large size
        self.image_size_a = tf.placeholder(dtype=tf.int32, shape=())  # ()
        self.window_size_a = tf.placeholder(dtype=tf.float32, shape=())  # (), float32, with grad
        self.raster_size_a = float(raster_size)

        self.pasted_image = self.image_pasting_sampling_v3()
        # (image_size, image_size, 1), [0.0-BG, 1.0-stroke]

    def image_pasting_sampling_v3(self):
        padding_size = tf.cast(tf.ceil(self.window_size_a / 2.0), tf.int32)

        x1y1_a = self.cursor_pos_a - self.window_size_a / 2.0  # (2), float32
        x2y2_a = self.cursor_pos_a + self.window_size_a / 2.0  # (2), float32

        x1y1_a_floor = tf.floor(x1y1_a)  # (2)
        x2y2_a_ceil = tf.ceil(x2y2_a)  # (2)

        cursor_pos_b_oricoord = (x1y1_a_floor + x2y2_a_ceil) / 2.0  # (2)
        cursor_pos_b = (cursor_pos_b_oricoord - x1y1_a) / self.window_size_a * self.raster_size_a  # (2)
        raster_size_b = (x2y2_a_ceil - x1y1_a_floor)  # (x, y)
        image_size_b = self.raster_size_a
        window_size_b = self.raster_size_a * (raster_size_b / self.window_size_a)  # (x, y)

        cursor_b_x, cursor_b_y = tf.split(cursor_pos_b, 2, axis=-1)  # (1)

        y1_b = cursor_b_y - (window_size_b[1] - 1.) / 2.
        x1_b = cursor_b_x - (window_size_b[0] - 1.) / 2.
        y2_b = y1_b + (window_size_b[1] - 1.)
        x2_b = x1_b + (window_size_b[0] - 1.)
        boxes_b = tf.concat([y1_b, x1_b, y2_b, x2_b], axis=-1)  # (4)
        boxes_b = boxes_b / tf.cast(image_size_b - 1, tf.float32)  # with grad to window_size_a

        box_ind_b = tf.ones((1), dtype=tf.int32)  # (1)
        box_ind_b = tf.cumsum(box_ind_b) - 1

        patch_canvas = tf.expand_dims(self.patch_canvas,
                                      axis=0)  # (1, raster_size, raster_size, 1), [0.0-BG, 1.0-stroke]
        boxes_b = tf.expand_dims(boxes_b, axis=0)  # (1, 4)

        valid_canvas = tf.image.crop_and_resize(patch_canvas, boxes_b, box_ind_b,
                                                crop_size=[raster_size_b[1], raster_size_b[0]])
        valid_canvas = valid_canvas[0]  # (raster_size_b, raster_size_b, 1)

        pad_up = tf.cast(x1y1_a_floor[1], tf.int32) + padding_size
        pad_down = self.image_size_a + padding_size - tf.cast(x2y2_a_ceil[1], tf.int32)
        pad_left = tf.cast(x1y1_a_floor[0], tf.int32) + padding_size
        pad_right = self.image_size_a + padding_size - tf.cast(x2y2_a_ceil[0], tf.int32)

        paddings = [[pad_up, pad_down],
                    [pad_left, pad_right],
                    [0, 0]]
        pad_img = tf.pad(valid_canvas, paddings=paddings, mode='CONSTANT',
                         constant_values=0.0)  # (H_p, W_p, 1), [0.0-BG, 1.0-stroke]

        pasted_image = pad_img[padding_size: padding_size + self.image_size_a,
                       padding_size: padding_size + self.image_size_a, :]
        # (image_size, image_size, 1), [0.0-BG, 1.0-stroke]
        return pasted_image


def image_pasting_sampling_v3(patch_image, cursor, image_size, window_size_f, pasting_func, sess):
    """
    :param patch_image:  (raster_size, raster_size), [0.0-BG, 1.0-stroke]
    :param cursor: (2), in size [0.0, 1.0)
    :param window_size_f: (), float32, [0.0, image_size)
    :return: (image_size, image_size), [0.0-BG, 1.0-stroke]
    """
    cursor_pos = cursor * float(image_size)
    pasted_image = sess.run(pasting_func.pasted_image,
                            feed_dict={pasting_func.patch_canvas: np.expand_dims(patch_image, axis=-1),
                                       pasting_func.cursor_pos_a: cursor_pos,
                                       pasting_func.image_size_a: image_size,
                                       pasting_func.window_size_a: window_size_f})
    # (image_size, image_size, 1), [0.0-BG, 1.0-stroke]
    pasted_image = pasted_image[:, :, 0]
    return pasted_image


def display_strokes_final(sess, pasting_func, data, init_cursor, image_size, infer_lengths, init_width,
                          save_base,
                          cursor_type='next', min_window_size=32, raster_size=128):
    """
    :param data: (N_strokes, 9): flag, x0, y0, x1, y1, x2, y2, r0, r2
    :return:
    """
    canvas = np.zeros((image_size, image_size), dtype=np.float32)  # [0.0-BG, 1.0-stroke]
    drawn_region = np.zeros_like(canvas)
    overlap_region = np.zeros_like(canvas)
    canvas_color_with_overlap = np.zeros((image_size, image_size, 3), dtype=np.float32)
    canvas_color_wo_overlap = np.zeros((image_size, image_size, 3), dtype=np.float32)
    canvas_color_with_moving = np.zeros((image_size, image_size, 3), dtype=np.float32)

    cursor_idx = 0

    if init_cursor.ndim == 1:
        init_cursor = [init_cursor]

    stroke_count = len(data)
    color_rgb_set = get_colors(stroke_count)  # list of (3,) in [0, 255]
    color_idx = 0

    valid_stroke_count = stroke_count - np.sum(data[:, 0]).astype(np.int32) + len(init_cursor)
    valid_color_rgb_set = get_colors(valid_stroke_count)  # list of (3,) in [0, 255]
    valid_color_idx = -1

    # print('Drawn stroke number', valid_stroke_count)
    # print('    flag  x1\t\t y1\t\t x2\t\t y2\t\t r2\t\t s2')

    for round_idx in range(len(infer_lengths)):
        round_length = infer_lengths[round_idx]

        cursor_pos = init_cursor[cursor_idx]  # (2)
        cursor_idx += 1

        prev_width = init_width
        prev_scaling = 1.0
        prev_window_size = float(raster_size)  # (1)

        for round_inner_i in range(round_length):
            stroke_idx = np.sum(infer_lengths[:round_idx]).astype(np.int32) + round_inner_i

            curr_window_size_raw = prev_scaling * prev_window_size
            curr_window_size_raw = np.maximum(curr_window_size_raw, min_window_size)
            curr_window_size_raw = np.minimum(curr_window_size_raw, image_size)

            pen_state = data[stroke_idx, 0]
            stroke_params = data[stroke_idx, 1:]  # (8)

            x1y1, x2y2, width2, scaling2 = stroke_params[0:2], stroke_params[2:4], stroke_params[4], stroke_params[5]
            x0y0 = np.zeros_like(x2y2)  # (2), [-1.0, 1.0]
            x0y0 = np.divide(np.add(x0y0, 1.0), 2.0)  # (2), [0.0, 1.0]
            x2y2 = np.divide(np.add(x2y2, 1.0), 2.0)  # (2), [0.0, 1.0]
            widths = np.stack([prev_width, width2], axis=0)  # (2)
            stroke_params_proc = np.concatenate([x0y0, x1y1, x2y2, widths], axis=-1)  # (8)

            next_width = stroke_params[4]
            next_scaling = stroke_params[5]
            next_window_size = next_scaling * curr_window_size_raw
            next_window_size = np.maximum(next_window_size, min_window_size)
            next_window_size = np.minimum(next_window_size, image_size)

            prev_width = next_width * curr_window_size_raw / next_window_size
            prev_scaling = next_scaling
            prev_window_size = curr_window_size_raw

            f = stroke_params_proc.tolist()  # (8)
            f += [1.0, 1.0]
            gt_stroke_img = draw(f)  # (H, W), [0.0-stroke, 1.0-BG]

            gt_stroke_img_large = image_pasting_sampling_v3(1.0 - gt_stroke_img, cursor_pos,
                                                            image_size,
                                                            curr_window_size_raw,
                                                            pasting_func, sess)  # [0.0-BG, 1.0-stroke]

            is_overlap = False

            if pen_state == 0:
                canvas += gt_stroke_img_large  # [0.0-BG, 1.0-stroke]

                curr_drawn_stroke_region = np.zeros_like(gt_stroke_img_large)
                curr_drawn_stroke_region[gt_stroke_img_large > 0.5] = 1
                intersection = drawn_region * curr_drawn_stroke_region
                # regard stroke with >50% overlap area as overlaped stroke
                if np.sum(intersection) / np.sum(curr_drawn_stroke_region) > 0.5:
                    # enlarge the stroke a bit for better visualization
                    overlap_region[gt_stroke_img_large > 0] += 1
                    is_overlap = True

                drawn_region[gt_stroke_img_large > 0.5] = 1

            color_rgb = color_rgb_set[color_idx]  # (3) in [0, 255]
            color_idx += 1

            color_rgb = np.reshape(color_rgb, (1, 1, 3)).astype(np.float32)
            color_stroke = np.expand_dims(gt_stroke_img_large, axis=-1) * (1.0 - color_rgb / 255.0)
            canvas_color_with_moving = canvas_color_with_moving * np.expand_dims((1.0 - gt_stroke_img_large),
                                                                                 axis=-1) + color_stroke  # (H, W, 3)

            if pen_state == 0:
                valid_color_idx += 1

            if pen_state == 0:
                valid_color_rgb = valid_color_rgb_set[valid_color_idx]  # (3) in [0, 255]
                # valid_color_idx += 1

                valid_color_rgb = np.reshape(valid_color_rgb, (1, 1, 3)).astype(np.float32)
                valid_color_stroke = np.expand_dims(gt_stroke_img_large, axis=-1) * (1.0 - valid_color_rgb / 255.0)
                canvas_color_with_overlap = canvas_color_with_overlap * np.expand_dims((1.0 - gt_stroke_img_large),
                                                                                       axis=-1) + valid_color_stroke  # (H, W, 3)
                if not is_overlap:
                    canvas_color_wo_overlap = canvas_color_wo_overlap * np.expand_dims((1.0 - gt_stroke_img_large),
                                                                                       axis=-1) + valid_color_stroke  # (H, W, 3)

            # update cursor_pos based on hps.cursor_type
            new_cursor_offsets = stroke_params[2:4] * (float(curr_window_size_raw) / 2.0)  # (1, 6), patch-level
            new_cursor_offset_next = new_cursor_offsets

            # important!!!
            new_cursor_offset_next = np.concatenate([new_cursor_offset_next[1:2], new_cursor_offset_next[0:1]], axis=-1)

            cursor_pos_large = cursor_pos * float(image_size)

            stroke_position_next = cursor_pos_large + new_cursor_offset_next  # (2), large-level

            if cursor_type == 'next':
                cursor_pos_large = stroke_position_next  # (2), large-level
            else:
                raise Exception('Unknown cursor_type')

            cursor_pos_large = np.minimum(np.maximum(cursor_pos_large, 0.0), float(image_size - 1))  # (2), large-level
            cursor_pos = cursor_pos_large / float(image_size)

    canvas_rgb = np.stack([np.clip(canvas, 0.0, 1.0) for _ in range(3)], axis=-1)
    canvas_black = 255 - np.round(canvas_rgb * 255.0).astype(np.uint8)
    canvas_color_with_overlap = 255 - np.round(canvas_color_with_overlap * 255.0).astype(np.uint8)
    canvas_color_wo_overlap = 255 - np.round(canvas_color_wo_overlap * 255.0).astype(np.uint8)
    canvas_color_with_moving = 255 - np.round(canvas_color_with_moving * 255.0).astype(np.uint8)

    canvas_black_png = Image.fromarray(canvas_black, 'RGB')
    canvas_black_save_path = os.path.join(save_base, 'output_rendered.png')
    canvas_black_png.save(canvas_black_save_path, 'PNG')

    canvas_color_png = Image.fromarray(canvas_color_with_overlap, 'RGB')
    canvas_color_save_path = os.path.join(save_base, 'output_order_with_overlap.png')
    canvas_color_png.save(canvas_color_save_path, 'PNG')

    canvas_color_wo_png = Image.fromarray(canvas_color_wo_overlap, 'RGB')
    canvas_color_wo_save_path = os.path.join(save_base, 'output_order_wo_overlap.png')
    canvas_color_wo_png.save(canvas_color_wo_save_path, 'PNG')

    canvas_color_m_png = Image.fromarray(canvas_color_with_moving, 'RGB')
    canvas_color_m_save_path = os.path.join(save_base, 'output_order_with_moving.png')
    canvas_color_m_png.save(canvas_color_m_save_path, 'PNG')


def visualize_drawing(dataset_type, image_name):
    assert dataset_type in ['clean', 'rough', 'face']
    assert image_name != ''

    data_base = './'

    min_window_size = 32
    raster_size = 128

    data_root = os.path.join(data_base, dataset_type, image_name)
    print('Visualizing image:', data_root)

    regenerate_base = os.path.join(data_root, 'regenerate')
    os.makedirs(regenerate_base, exist_ok=True)

    # differentiable pasting graph
    paste_v3_func = DiffPastingV3(raster_size)

    tfconfig = tf.ConfigProto()
    tfconfig.gpu_options.allow_growth = True
    sess = tf.InteractiveSession(config=tfconfig)
    sess.run(tf.global_variables_initializer())

    npz_path = os.path.join(data_root, 'output_vector.npz')
    data = np.load(npz_path, encoding='latin1', allow_pickle=True)
    strokes_data = data['strokes_data']
    init_cursors = data['init_cursors']
    image_size = data['image_size']
    round_length = data['round_length']
    init_width = data['init_width']

    if 'face' in dataset_type:
        round_lengths = [round_length]
    else:
        if round_length.ndim == 0:
            round_lengths = [round_length for _ in range(init_cursors.shape[0])]
        else:
            round_lengths = round_length

    # print('round_lengths', round_lengths)

    display_strokes_final(sess, paste_v3_func,
                          strokes_data, init_cursors, image_size, round_lengths, init_width,
                          regenerate_base,
                          min_window_size=min_window_size, raster_size=raster_size)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', '-d', type=str, choices=['clean', 'rough', 'face'], default='clean',
                        help="choose a data type")
    parser.add_argument('--image', '-i', type=str, default='', help="image name")
    args = parser.parse_args()

    visualize_drawing(args.data, args.image)
